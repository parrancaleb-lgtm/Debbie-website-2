# Caleb & Debbie Monthsary Website

Open `index.html` locally to preview it.

Open `admin.html` to use the prototype content manager.
Prototype password: `CHANGE-ME`

This version is intentionally a local prototype. Uploaded files are stored in browser localStorage, which is NOT appropriate for large videos or real security.

For the production version, connect:
- Supabase Auth for authentication
- Supabase Storage for photos/videos
- Supabase Postgres for memories/timeline/content
- Row Level Security (RLS)
- A static host such as Cloudflare Pages

Never expose a Supabase service-role key in browser code.
